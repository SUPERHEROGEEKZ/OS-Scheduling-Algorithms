public class Main
{
    public static void main(String[] args)
    {
	jobs myJobs = new jobs();
	myJobs.readFile();
	scheduling schedule = new scheduling(myJobs.jobs, myJobs.jobCount);
	System.out.println("\n" + "FCFS:");
	schedule.fcfs();
        System.out.println("\n" + "SPN:");
	schedule.spn();
	System.out.println("\n" + "HRRN:");
        schedule.hrrn();
	System.out.print("\n");
    }
}
