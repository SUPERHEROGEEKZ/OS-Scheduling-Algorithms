import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;

public class jobs
{
    public int[][] jobs = new int[26][3];
    public int jobCount = 0;
    public void readFile()
    {
	try
	    {
		Scanner scanner = new Scanner(new File("jobs.txt"));
		int i = 0;
		int expectedChar = 65;    	
		int lastStartTime = -1;
		while(scanner.hasNext())
		    {
			int ch = (int)scanner.next().charAt(0);
			if (ch == expectedChar && ch <= 90) //Validating job names
			    { 
				jobs[i][0] = ch;
				int nextStartTime = scanner.nextInt();
				if (nextStartTime > lastStartTime)
				    {
					jobs[i][1] = nextStartTime;
					lastStartTime = nextStartTime; //Reset last start time to current job
					jobs[i][2] = scanner.nextInt();
				    }			
				else
				    {
					System.out.println("Start times not sequential!");
					System.exit(0);
				    }			
			    }	
			else
			    {
				System.out.println("Invalid file contents!");
				System.exit(0);
			    }			
			i++;
			expectedChar++;
		    }
		jobCount = i;
		//System.out.println(Arrays.deepToString(jobs));
		scanner.close();
	    }
	catch (IOException e)
	    {
		System.err.println(e);
		System.out.println("Error reading file!");
	    }
	
    }
    
}

