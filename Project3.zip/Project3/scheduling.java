import java.util.Arrays;

public class scheduling 
{
    private void printJob(int job, int numSpaces, int duration) 
    {
	String spaces = " ";
	String x = "";
	
	for (int j = 0; j < numSpaces; j++) 
	    {
		spaces += " ";
	    }
	for (int k = 0; k < duration; k++) 
	    {
		x += "X";
	    }
	System.out.println((char) job + spaces + x);
    }
    
    int[][] jobs;
    int jobCount;
    
    public scheduling(int[][] j, int c) 
    {
	jobs = j;
	jobCount = c;
    }

    public void fcfs() // First Come First Serve
    {
	printJob(jobs[0][0], jobs[0][1], jobs[0][2]);
	int totalNumSpaces = jobs[0][2];
	for (int i = 1; i < jobCount; i++) 
	    {
		int numSpaces = Math.max(jobs[i][1], totalNumSpaces);
		totalNumSpaces = numSpaces + jobs[i][2];
		printJob(jobs[i][0], numSpaces, jobs[i][2]);
	    }
    }

    private int getShortestProcess(int[][] jobs, boolean[] isScheduled, int currentTick) 
    {
	int currentShortest = 100000000;
	int highestRatioIndex = -1;
	for (int i = 0; i < jobCount; i++) // Searching through jobs within current tick (0-current tick)
	    {
		if (!isScheduled[i] && jobs[i][1] <= currentTick && jobs[i][2] < currentShortest) 
		    {
			currentShortest = jobs[i][2];
			highestRatioIndex = i;
		    }
	    }
	return highestRatioIndex;
    }

    public void spn() 
    {
	printJob(jobs[0][0], jobs[0][1], jobs[0][2]); // Choosing 1st job
	boolean[] isScheduled = new boolean[jobCount];
	Arrays.fill(isScheduled, false);
	isScheduled[0] = true;
	int currentTick = jobs[0][2] + jobs[0][1]; // Current tick the time is at
	int totalNumSpaces = jobs[0][2];
	int lastShortestIndex = 0;
	
	for (int i = 0; i < jobCount - 1; i++) 
	    {
		int shorestIndex = getShortestProcess(jobs, isScheduled, currentTick);
		int numSpaces;
		
		if (shorestIndex != -1) 
		    {
			isScheduled[shorestIndex] = true;
			numSpaces = Math.max(jobs[shorestIndex][1], totalNumSpaces);
			printJob(jobs[shorestIndex][0], numSpaces, jobs[shorestIndex][2]);
			totalNumSpaces = numSpaces + jobs[shorestIndex][2];
			lastShortestIndex = shorestIndex;
			currentTick += jobs[shorestIndex][2];
		    } 
		else 
		    {
			isScheduled[lastShortestIndex + 1] = true;
			numSpaces = Math.max(jobs[lastShortestIndex + 1][1], totalNumSpaces);
			printJob(jobs[lastShortestIndex + 1][0], numSpaces, jobs[lastShortestIndex + 1][2]);
			totalNumSpaces = numSpaces + jobs[lastShortestIndex + 1][2];
			lastShortestIndex += 1;
			currentTick += jobs[lastShortestIndex + 1][2];
		    }
	    }
    }
    
    private int getHighestRatio(int[][] jobs, boolean[] isScheduled, int currentTick) 
    {
	int currentHighest = -1;
	int highestIndex = -1;
	for (int i = 0; i < jobCount; i++) // Searching through jobs within current tick (0-current tick)
	    {
		int ratio = ((currentTick - jobs[i][1]) + jobs[i][2]) / jobs[i][2];
		if (!isScheduled[i] && jobs[i][1] <= currentTick && ratio > currentHighest) 
		    {
			currentHighest = ratio;
			highestIndex = i;
		    }
	    }
	return highestIndex;
    }
    
    public void hrrn() 
    {
	printJob(jobs[0][0], jobs[0][1], jobs[0][2]); // Choosing 1st job
	boolean[] isScheduled = new boolean[jobCount];
	Arrays.fill(isScheduled, false);
	isScheduled[0] = true;
	int currentTick = jobs[0][2] + jobs[0][1]; // Current tick the time is at
	int totalNumSpaces = jobs[0][2];
	int lastHighestRatioIndex = 0;
	for (int i = 0; i < jobCount - 1; i++) 
	    {
		int highestRatioIndex = getHighestRatio(jobs, isScheduled, currentTick);
		int numSpaces;
		
		if (highestRatioIndex != -1) 
		    {
			isScheduled[highestRatioIndex] = true;
			numSpaces = Math.max(jobs[highestRatioIndex][1], totalNumSpaces);
			printJob(jobs[highestRatioIndex][0], numSpaces, jobs[highestRatioIndex][2]);
			totalNumSpaces = numSpaces + jobs[highestRatioIndex][2];
			lastHighestRatioIndex = highestRatioIndex;
			currentTick += jobs[highestRatioIndex][2];
		    } 
		else 
		    {
			isScheduled[lastHighestRatioIndex + 1] = true;
			numSpaces = Math.max(jobs[lastHighestRatioIndex + 1][1], totalNumSpaces);
			printJob(jobs[lastHighestRatioIndex + 1][0], numSpaces, jobs[lastHighestRatioIndex + 1][2]);
			totalNumSpaces = numSpaces + jobs[lastHighestRatioIndex + 1][2];
			lastHighestRatioIndex += 1;
			currentTick += jobs[lastHighestRatioIndex + 1][2];
		    }
	    }
    }
}
