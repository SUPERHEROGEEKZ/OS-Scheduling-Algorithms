————————
LIST OF FILES:
————————
Main.java
jobs.java
scheduling.java
jobs.txt
Project 3 Summary.docx
README.txt

———————————
FILE DESCRIPTIONS:
———————————
Main.java: This is the main java source file that runs the program. It includes the function calls for the scheduling algorithms.

jobs.java: This is a java source file that implements the scanner. It validates the contents of the text file being read.

scheduling.java: This is a java source file that contains the functions for all of the scheduling algorithms. It outputs the graph of each of the algorithms onto the screen depending on the contents of the text file.

jobs.txt: This is a text file that has a list of jobs with their start time and duration (Made by professor).

Project 3 Summary.docx: This is a word document that contains a summary of the project and how I implemented it.

README.txt: This is a text file that has a list of files, the description of each file, and instructions on how to compile and run the project.

——————————————————————
HOW TO COMPILE AND RUN THE PROJECT:
——————————————————————
You can use this program to run in the terminal or anything that supports UNIX/LINUX.

STEPS:
1) Unzip program
2) Move program files in terminal directory
3) Compile files using the command “javac Main.java”, “javac jobs.java”, “javac scheduling.java”
4) Run files using the command “java Main”